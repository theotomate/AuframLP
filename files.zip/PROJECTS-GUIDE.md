# How to Customize Your Projects

## Adding/Editing Projects on the Landing Page (index.html)

### Location
Find the `<!-- Projects Section -->` in the HTML (around line 742)

### To Edit a Project Card:

1. **Change the Icon**: Replace the emoji between the `<div class="project-image">` tags
   ```html
   <div class="project-image">
       🚀  <!-- Change this emoji -->
   </div>
   ```

2. **Change the Category**: Edit the text in the category span
   ```html
   <span class="project-category">AI Integration</span>
   ```

3. **Change the Title**: Edit the h3 text
   ```html
   <h3>Your Project Title Here</h3>
   ```

4. **Change the Description**: Edit the paragraph text
   ```html
   <p>Your project description here...</p>
   ```

5. **Update the Link**: Change the project number in the href
   ```html
   <a href="project-details.html?project=1" class="project-card">
   <!-- Change the number to match your project -->
   ```

### To Add More Projects:

Simply copy one entire `<a href="project-details.html?project=X" class="project-card">...</a>` block and paste it before the closing `</div>` of `projects-grid`. Then update all the content.

## Customizing the Project Details Page (project-details.html)

This is a template you'll duplicate for each project. Here's how:

### Step 1: Create a New File
- Copy `project-details.html` 
- Rename it (e.g., `project-1.html`, `project-2.html`, etc.)
- Or keep the same file and use URL parameters (already set up)

### Step 2: Customize the Content

**Header Section:**
- Change the category badge
- Update the project title
- Fill in Client, Industry, Timeline metadata

**Hero Image:**
- Replace the emoji with your project icon/image
- Or add an actual image: `<img src="your-image.jpg" alt="Project" style="width:100%; height:100%; object-fit:cover;">`

**Content Sections:**

1. **Project Overview**: Replace placeholder text with your project story
2. **The Challenge**: List the client's pain points and problems
3. **Our Solution**: Describe your approach and implementation
4. **The Results**: Update the metrics with real numbers
   ```html
   <span class="result-number">75%</span>
   <span class="result-label">Your Metric</span>
   ```
5. **Testimonial**: Add real client feedback (or remove this section)

### Step 3: Update Links

If you created separate files (project-1.html, project-2.html, etc.):

Go back to `index.html` and update the links:
```html
<a href="project-1.html" class="project-card">
<!-- Instead of project-details.html?project=1 -->
```

## Quick Tips

### Using Real Images Instead of Emojis

Replace the project image div with an img tag:
```html
<!-- Old (emoji) -->
<div class="project-image">🚀</div>

<!-- New (real image) -->
<div class="project-image">
    <img src="images/project-1.jpg" alt="Project Name" style="width:100%; height:100%; object-fit:cover; border-radius: 20px 20px 0 0;">
</div>
```

### Colors and Categories

Predefined categories in the CSS match:
- AI Integration (primary green)
- Process Automation
- Data Analytics

You can add more by updating the CSS if needed.

### Animation Delays

The cards animate in sequence. If you add more than 3 projects, add more animation delays:
```css
.project-card:nth-child(4) { animation-delay: 0.4s; }
.project-card:nth-child(5) { animation-delay: 0.5s; }
```

## Example: Full Project Card

```html
<a href="project-details.html?project=4" class="project-card">
    <div class="project-image">
        🎯
    </div>
    <div class="project-content">
        <span class="project-category">Custom Solution</span>
        <h3>E-commerce Automation Platform</h3>
        <p>Built an end-to-end automation system that reduced order processing time by 90% and increased customer satisfaction scores.</p>
        <span class="project-link">View Case Study</span>
    </div>
</a>
```

## Need Help?

All the text is clearly marked with placeholder text like "Replace this text..." or "Add your content here...". Just search and replace these with your actual project information.
